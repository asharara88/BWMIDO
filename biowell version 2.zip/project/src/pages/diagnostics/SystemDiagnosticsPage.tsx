import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { runAllDiagnostics } from '../../utils/diagnostics';
import { Activity, MessageCircle, Database, Zap, CheckCircle, XCircle, RefreshCw } from 'lucide-react';

const SystemDiagnosticsPage = () => {
  const [results, setResults] = useState<Record<string, any> | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const runDiagnostics = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const diagnosticResults = await runAllDiagnostics();
      setResults(diagnosticResults);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    runDiagnostics();
  }, []);

  const getStatusIcon = (success: boolean | undefined) => {
    if (success === undefined) return <RefreshCw className="h-5 w-5 animate-spin text-warning" />;
    return success ? 
      <CheckCircle className="h-5 w-5 text-success" /> : 
      <XCircle className="h-5 w-5 text-error" />;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6">
          <h1 className="text-2xl font-bold md:text-3xl">System Diagnostics</h1>
          <p className="text-text-light">
            Check the status of various system components and APIs
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <div className="md:col-span-2">
            <div className="rounded-xl border border-[hsl(var(--color-border))] bg-[hsl(var(--color-card))] p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold">System Diagnostics</h2>
                <button
                  onClick={runDiagnostics}
                  disabled={loading}
                  className="flex items-center gap-2 rounded-lg border border-[hsl(var(--color-border))] bg-[hsl(var(--color-surface-1))] px-3 py-1.5 text-sm text-text-light transition-colors hover:bg-[hsl(var(--color-card-hover))] hover:text-text disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {loading ? (
                    <RefreshCw className="h-4 w-4 animate-spin" />
                  ) : (
                    <RefreshCw className="h-4 w-4" />
                  )}
                  {loading ? 'Running...' : 'Run Diagnostics'}
                </button>
              </div>

              {error && (
                <div className="mt-4 rounded-lg bg-error/10 p-3 text-sm text-error">
                  <p className="font-medium">Error running diagnostics</p>
                  <p>{error}</p>
                </div>
              )}

              <div className="mt-4 space-y-2">
                {results && (
                  <>
                    <div className="flex items-center justify-between rounded-lg border border-[hsl(var(--color-border))] bg-[hsl(var(--color-surface-1))] p-3">
                      <div className="flex items-center gap-3">
                        {getStatusIcon(results.supabase?.success)}
                        <span>Supabase Connection</span>
                      </div>
                      <span className={`text-sm ${results.supabase?.success ? 'text-success' : 'text-error'}`}>
                        {results.supabase?.success ? 'OK' : 'Failed'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between rounded-lg border border-[hsl(var(--color-border))] bg-[hsl(var(--color-surface-1))] p-3">
                      <div className="flex items-center gap-3">
                        {getStatusIcon(results.openai?.success)}
                        <span>OpenAI Proxy</span>
                      </div>
                      <span className={`text-sm ${results.openai?.success ? 'text-success' : 'text-error'}`}>
                        {results.openai?.success ? 'OK' : 'Failed'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between rounded-lg border border-[hsl(var(--color-border))] bg-[hsl(var(--color-surface-1))] p-3">
                      <div className="flex items-center gap-3">
                        {getStatusIcon(results.chatHistory?.success)}
                        <span>Chat History Access</span>
                      </div>
                      <span className={`text-sm ${results.chatHistory?.success ? 'text-success' : 'text-error'}`}>
                        {results.chatHistory?.success ? 'OK' : 'Failed'}
                      </span>
                    </div>
                  </>
                )}

                {loading && !results && (
                  <div className="flex items-center justify-center py-8">
                    <RefreshCw className="h-8 w-8 animate-spin text-primary" />
                  </div>
                )}
              </div>

              <div className="mt-4 rounded-lg bg-[hsl(var(--color-surface-1))] p-3 text-sm text-text-light">
                <p>
                  {loading ? 'Running diagnostics...' : 
                   error ? 'Diagnostics failed with errors' :
                   !results ? 'Waiting for results...' :
                   Object.values(results).every(r => r.success) ? 
                     'All systems operational' : 
                     'Some systems are experiencing issues'}
                </p>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-[hsl(var(--color-border))] bg-[hsl(var(--color-card))] p-6">
            <div className="mb-4 flex items-center gap-3">
              <div className="rounded-xl bg-primary/10 p-3 text-primary">
                <MessageCircle className="h-6 w-6" />
              </div>
              <h2 className="text-xl font-bold">Chat System</h2>
            </div>
            <p className="mb-4 text-text-light">
              The chat system relies on Supabase Edge Functions to proxy requests to OpenAI's API. 
              This architecture keeps your API keys secure and allows for custom processing of messages.
            </p>
            <div className="rounded-lg bg-[hsl(var(--color-surface-1))] p-4">
              <h3 className="mb-2 text-sm font-medium">Troubleshooting Steps</h3>
              <ul className="space-y-2 text-sm text-text-light">
                <li>• Verify that the OpenAI Edge Function is deployed</li>
                <li>• Check that the OPENAI_API_KEY is set in Supabase</li>
                <li>• Ensure proper CORS configuration in the Edge Function</li>
                <li>• Verify authentication is working correctly</li>
              </ul>
            </div>
          </div>

          <div className="rounded-xl border border-[hsl(var(--color-border))] bg-[hsl(var(--color-card))] p-6">
            <div className="mb-4 flex items-center gap-3">
              <div className="rounded-xl bg-primary/10 p-3 text-primary">
                <Database className="h-6 w-6" />
              </div>
              <h2 className="text-xl font-bold">Database System</h2>
            </div>
            <p className="mb-4 text-text-light">
              Biowell uses Supabase for data storage, authentication, and real-time features. 
              The database contains tables for user profiles, health metrics, supplements, and more.
            </p>
            <div className="rounded-lg bg-[hsl(var(--color-surface-1))] p-4">
              <h3 className="mb-2 text-sm font-medium">Troubleshooting Steps</h3>
              <ul className="space-y-2 text-sm text-text-light">
                <li>• Verify Supabase URL and API key in environment variables</li>
                <li>• Check Row Level Security (RLS) policies</li>
                <li>• Ensure tables have proper foreign key relationships</li>
                <li>• Verify that triggers and functions are working</li>
              </ul>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default SystemDiagnosticsPage;